#ifndef _SHADER_H
#define _SHADER_H

// function to load shaders
GLuint loadShaders(const string vertexShaderFile, const string fragmentShaderFile);

#endif
